-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : ven. 10 fév. 2023 à 16:10
-- Version du serveur : 10.5.18-MariaDB-0+deb11u1
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `Messagerie`
--

-- --------------------------------------------------------

--
-- Structure de la table `Message`
--

CREATE TABLE `Message` (
  `id` int(11) NOT NULL,
  `dateHeure` datetime NOT NULL,
  `idUser` int(11) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `Message`
--

INSERT INTO `Message` (`id`, `dateHeure`, `idUser`, `message`) VALUES
(286, '2023-02-10 13:55:24', 3, 'coucou'),
(287, '2023-02-10 13:55:33', 3, 'coucou'),
(288, '2023-02-10 13:55:44', 3, 'hello'),
(289, '2023-02-10 13:56:07', 3, 'hello'),
(290, '2023-02-10 13:56:14', 3, 'hello'),
(291, '2023-02-10 13:56:35', 3, 'hello'),
(292, '2023-02-10 13:56:54', 3, 'ciyuciy'),
(293, '2023-02-10 13:58:08', 84, 'bonjour'),
(294, '2023-02-10 14:04:56', 84, 'boundour'),
(295, '2023-02-10 14:07:09', 84, 'Vraiment pas ouf le site ....'),
(296, '2023-02-10 14:07:15', 86, 'coucou je suis jojo'),
(298, '2023-02-10 14:21:44', 85, 'ronaldo > messi caca'),
(299, '2023-02-10 14:22:25', 87, 'Ronaldo<messi'),
(300, '2023-02-10 14:22:33', 87, 'Tibow == Faustin'),
(301, '2023-02-10 14:22:43', 87, 'Tom <<<< Faustin'),
(302, '2023-02-10 14:22:43', 87, 'je suis gay et jaime les hommes');

-- --------------------------------------------------------

--
-- Structure de la table `User`
--

CREATE TABLE `User` (
  `id` int(11) NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `pseudo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `User`
--

INSERT INTO `User` (`id`, `login`, `password`, `pseudo`) VALUES
(2, 'root', 'roote', 'BelleGosse'),
(3, 'dam', 'dam', 'damiens'),
(69, 'coucou', 'coucou', 'dd'),
(84, 'htabary', 'azerty', ' Hugo TablouRayDVD'),
(85, 'aa', 'aa', 'aa'),
(86, 'jojo', 'bernard', 'xX_killerDu80_Xx'),
(87, 'damso', 'damso', 'damso');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Message`
--
ALTER TABLE `Message`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idUser` (`idUser`);

--
-- Index pour la table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Message`
--
ALTER TABLE `Message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=303;

--
-- AUTO_INCREMENT pour la table `User`
--
ALTER TABLE `User`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Message`
--
ALTER TABLE `Message`
  ADD CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`idUser`) REFERENCES `User` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
